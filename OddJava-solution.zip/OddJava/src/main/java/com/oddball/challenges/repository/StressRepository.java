package com.oddball.challenges.repository;

import com.oddball.challenges.model.stress.Stress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface StressRepository extends JpaRepository<Stress, Long> {

    /**
     * Finds all stress records where date is >= startDate and < endDate.
     */
    List<Stress> findAllByDateGreaterThanEqualAndDateLessThan(Date startDate, Date endDate);
}
