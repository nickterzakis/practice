package com.oddball.challenges.controller;

import com.oddball.challenges.dto.BadDayReportRequest;
import com.oddball.challenges.dto.BadDayStreak;
import com.oddball.challenges.dto.WeeklyBadDayCount;
import com.oddball.challenges.service.ReportGenerationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class OddJavaController {

    private final ReportGenerationService service;

    @Autowired
    public OddJavaController(ReportGenerationService service) {
        this.service = service;
    }

    /**
     * Report 1: given a start date, returns (and prints to console) the users
     * who had 2+ Bad Days in that week, sorted by decreasing Bad Day count.
     *
     * Example request body: { "startDate": "2017-05-07" }
     */
    @PostMapping("/bad-day-report")
    public ResponseEntity<List<WeeklyBadDayCount>> generateWeeklyBadDayReport(
            @RequestBody BadDayReportRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.generateWeeklyBadDayReport(request));
    }

    /**
     * Report 2: returns (and prints to console) the five longest consecutive
     * Bad Day streaks across all available data, sorted by decreasing length.
     */
    @GetMapping("/bad-day-streaks")
    public ResponseEntity<List<BadDayStreak>> generateBadDayStreakReport() {
        return ResponseEntity.ok(service.generateBadDayStreakReport());
    }
}
