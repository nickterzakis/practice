package com.oddball.challenges.service;

import com.oddball.challenges.dto.BadDayReportRequest;
import com.oddball.challenges.dto.BadDayStreak;
import com.oddball.challenges.dto.WeeklyBadDayCount;

import java.util.List;

public interface ReportGenerationService {

    /**
     * Report 1: users who had two or more Bad Days during the requested week,
     * along with their Bad Day count, sorted in decreasing order of Bad Days.
     */
    List<WeeklyBadDayCount> generateWeeklyBadDayReport(BadDayReportRequest request);

    /**
     * Report 2: the five longest consecutive Bad Day streaks across all
     * available mood/stress data, sorted in decreasing order of streak length.
     */
    List<BadDayStreak> generateBadDayStreakReport();
}
