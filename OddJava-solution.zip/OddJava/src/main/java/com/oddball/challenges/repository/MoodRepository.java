package com.oddball.challenges.repository;

import com.oddball.challenges.model.mood.Mood;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface MoodRepository extends JpaRepository<Mood, Long> {

    /**
     * Finds all moods where date is >= startDate and < endDate.
     * (Using two separate bounds instead of "Between" because Between is
     * inclusive on both ends, and our reporting window is [startDate, endDate).)
     */
    List<Mood> findAllByDateGreaterThanEqualAndDateLessThan(Date startDate, Date endDate);
}
