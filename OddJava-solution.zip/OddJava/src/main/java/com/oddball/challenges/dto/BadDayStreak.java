package com.oddball.challenges.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDate;

/**
 * Represents a single row of "Report 2" from the README:
 * one of the five longest consecutive Bad Day streaks across
 * all the data, for a single user.
 */
@Getter
@AllArgsConstructor
public class BadDayStreak {

    private String username;

    private int streakLength;

    private LocalDate startDate;
}
