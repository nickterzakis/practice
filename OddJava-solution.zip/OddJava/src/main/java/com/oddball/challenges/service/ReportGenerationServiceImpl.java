package com.oddball.challenges.service;

import com.oddball.challenges.dto.BadDayReportRequest;
import com.oddball.challenges.dto.BadDayStreak;
import com.oddball.challenges.dto.WeeklyBadDayCount;
import com.oddball.challenges.model.mood.Mood;
import com.oddball.challenges.model.stress.Stress;
import com.oddball.challenges.model.user.User;
import com.oddball.challenges.repository.MoodRepository;
import com.oddball.challenges.repository.StressRepository;
import com.oddball.challenges.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

@Service
public class ReportGenerationServiceImpl implements ReportGenerationService {

    private static final int MAX_STREAKS_TO_REPORT = 5;
    private static final int MIN_BAD_DAYS_FOR_WEEKLY_REPORT = 2;
    private static final int NEUTRAL_MOOD_OR_STRESS = 3;
    private static final Set<Integer> BAD_MOODS = new HashSet<>(Arrays.asList(1, 2));
    private static final Set<Integer> HIGH_STRESS = new HashSet<>(Arrays.asList(4, 5));

    private final UserRepository userRepository;
    private final MoodRepository moodRepository;
    private final StressRepository stressRepository;

    @Autowired
    public ReportGenerationServiceImpl(UserRepository userRepository,
                                        MoodRepository moodRepository,
                                        StressRepository stressRepository) {
        this.userRepository = userRepository;
        this.moodRepository = moodRepository;
        this.stressRepository = stressRepository;
    }

    @Override
    public List<WeeklyBadDayCount> generateWeeklyBadDayReport(BadDayReportRequest request) {
        List<Mood> moods = moodRepository.findAllByDateGreaterThanEqualAndDateLessThan(
                request.getStartDate(), request.getEndDate());
        List<Stress> stresses = stressRepository.findAllByDateGreaterThanEqualAndDateLessThan(
                request.getStartDate(), request.getEndDate());

        Map<Long, Map<LocalDate, Integer>> moodsByUser = groupMoodsByUser(moods);
        Map<Long, Map<LocalDate, Integer>> stressesByUser = groupStressesByUser(stresses);
        Map<Long, String> usernamesById = usernamesById();

        LocalDate start = toLocalDate(request.getStartDate());
        LocalDate end = toLocalDate(request.getEndDate());

        List<WeeklyBadDayCount> report = new ArrayList<>();
        for (Long userId : allUserIds(moodsByUser, stressesByUser)) {
            Map<LocalDate, Integer> userMoods = moodsByUser.getOrDefault(userId, Collections.emptyMap());
            Map<LocalDate, Integer> userStresses = stressesByUser.getOrDefault(userId, Collections.emptyMap());

            long badDays = 0;
            for (LocalDate date = start; date.isBefore(end); date = date.plusDays(1)) {
                if (isBadDay(userMoods.get(date), userStresses.get(date))) {
                    badDays++;
                }
            }

            if (badDays >= MIN_BAD_DAYS_FOR_WEEKLY_REPORT) {
                String username = usernamesById.getOrDefault(userId, "user-" + userId);
                report.add(new WeeklyBadDayCount(username, badDays));
            }
        }

        report.sort(Comparator.comparingLong(WeeklyBadDayCount::getBadDayCount).reversed());
        printWeeklyReport(report);
        return report;
    }

    @Override
    public List<BadDayStreak> generateBadDayStreakReport() {
        List<Mood> moods = moodRepository.findAll();
        List<Stress> stresses = stressRepository.findAll();

        Map<Long, Map<LocalDate, Integer>> moodsByUser = groupMoodsByUser(moods);
        Map<Long, Map<LocalDate, Integer>> stressesByUser = groupStressesByUser(stresses);
        Map<Long, String> usernamesById = usernamesById();

        List<BadDayStreak> allStreaks = new ArrayList<>();

        for (Long userId : allUserIds(moodsByUser, stressesByUser)) {
            Map<LocalDate, Integer> userMoods = moodsByUser.getOrDefault(userId, Collections.emptyMap());
            Map<LocalDate, Integer> userStresses = stressesByUser.getOrDefault(userId, Collections.emptyMap());

            TreeSet<LocalDate> datesWithData = new TreeSet<>();
            datesWithData.addAll(userMoods.keySet());
            datesWithData.addAll(userStresses.keySet());

            if (datesWithData.isEmpty()) {
                continue;
            }

            BadDayStreak bestStreakForUser = longestStreakForUser(
                    usernamesById.getOrDefault(userId, "user-" + userId),
                    datesWithData.first(),
                    datesWithData.last(),
                    userMoods,
                    userStresses);

            if (bestStreakForUser != null) {
                allStreaks.add(bestStreakForUser);
            }
        }

        List<BadDayStreak> topStreaks = allStreaks.stream()
                .sorted(Comparator.comparingInt(BadDayStreak::getStreakLength).reversed())
                .limit(MAX_STREAKS_TO_REPORT)
                .collect(Collectors.toList());

        printStreakReport(topStreaks);
        return topStreaks;
    }

    /**
     * Walks day-by-day from earliest to latest (inclusive) and tracks the
     * longest run of consecutive Bad Days for a single user.
     */
    private BadDayStreak longestStreakForUser(String username,
                                               LocalDate earliest,
                                               LocalDate latest,
                                               Map<LocalDate, Integer> userMoods,
                                               Map<LocalDate, Integer> userStresses) {
        int currentStreak = 0;
        LocalDate currentStreakStart = null;

        int bestStreak = 0;
        LocalDate bestStreakStart = null;

        for (LocalDate date = earliest; !date.isAfter(latest); date = date.plusDays(1)) {
            boolean badDay = isBadDay(userMoods.get(date), userStresses.get(date));

            if (badDay) {
                if (currentStreak == 0) {
                    currentStreakStart = date;
                }
                currentStreak++;
                if (currentStreak > bestStreak) {
                    bestStreak = currentStreak;
                    bestStreakStart = currentStreakStart;
                }
            } else {
                currentStreak = 0;
                currentStreakStart = null;
            }
        }

        return bestStreak > 0 ? new BadDayStreak(username, bestStreak, bestStreakStart) : null;
    }

    /**
     * A day is a Bad Day when:
     *  - mood is 1 or 2, OR
     *  - mood is 3 (neutral) and stress is 4 or 5.
     * Missing mood or stress data for a day defaults to neutral (3).
     */
    private boolean isBadDay(Integer mood, Integer stress) {
        int effectiveMood = mood != null ? mood : NEUTRAL_MOOD_OR_STRESS;
        int effectiveStress = stress != null ? stress : NEUTRAL_MOOD_OR_STRESS;

        if (BAD_MOODS.contains(effectiveMood)) {
            return true;
        }
        return effectiveMood == NEUTRAL_MOOD_OR_STRESS && HIGH_STRESS.contains(effectiveStress);
    }

    private Set<Long> allUserIds(Map<Long, Map<LocalDate, Integer>> moodsByUser,
                                  Map<Long, Map<LocalDate, Integer>> stressesByUser) {
        Set<Long> userIds = new HashSet<>();
        userIds.addAll(moodsByUser.keySet());
        userIds.addAll(stressesByUser.keySet());
        return userIds;
    }

    private Map<Long, Map<LocalDate, Integer>> groupMoodsByUser(List<Mood> moods) {
        Map<Long, Map<LocalDate, Integer>> result = new HashMap<>();
        for (Mood mood : moods) {
            result.computeIfAbsent(mood.getUserId(), id -> new HashMap<>())
                    .put(toLocalDate(mood.getDate()), mood.getMood());
        }
        return result;
    }

    private Map<Long, Map<LocalDate, Integer>> groupStressesByUser(List<Stress> stresses) {
        Map<Long, Map<LocalDate, Integer>> result = new HashMap<>();
        for (Stress stress : stresses) {
            result.computeIfAbsent(stress.getUserId(), id -> new HashMap<>())
                    .put(toLocalDate(stress.getDate()), stress.getStress());
        }
        return result;
    }

    private Map<Long, String> usernamesById() {
        return userRepository.findAll().stream()
                .collect(Collectors.toMap(User::getId, User::getUserName));
    }

    private LocalDate toLocalDate(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    private void printWeeklyReport(List<WeeklyBadDayCount> report) {
        System.out.println("=== Bad Day Report: users with 2+ Bad Days this week (sorted desc) ===");
        if (report.isEmpty()) {
            System.out.println("No users had 2 or more Bad Days this week.");
        }
        for (WeeklyBadDayCount entry : report) {
            System.out.printf("%s - %d bad day(s)%n", entry.getUsername(), entry.getBadDayCount());
        }
    }

    private void printStreakReport(List<BadDayStreak> streaks) {
        System.out.println("=== Top 5 Longest Bad Day Streaks (sorted desc) ===");
        for (BadDayStreak streak : streaks) {
            System.out.printf("%s - %d consecutive bad day(s) starting %s%n",
                    streak.getUsername(), streak.getStreakLength(), streak.getStartDate());
        }
    }
}
