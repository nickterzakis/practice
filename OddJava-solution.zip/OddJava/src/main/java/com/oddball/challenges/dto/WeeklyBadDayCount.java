package com.oddball.challenges.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Represents a single row of "Report 1" from the README:
 * a user who had two or more Bad Days in the requested week,
 * along with how many Bad Days they had.
 */
@Getter
@AllArgsConstructor
public class WeeklyBadDayCount {

    private String username;

    private long badDayCount;
}
